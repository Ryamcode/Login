<?php
session_start();
include("connect.php");

// Check if session is active, if not, redirect to login
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self';">
</head>

<body>
    <div style="text-align:center; padding:15%;">
        <p style="font-size:50px; font-weight:bold;">
            Hello
            <?php
            if (isset($_SESSION['email'])) {
                $email = $_SESSION['email'];
                $stmt = $conn->prepare("SELECT firstName, lastName FROM users WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo htmlspecialchars($row['firstName'] . ' ' . $row['lastName']);  // Escape for safety
                }
                $stmt->close();
            }
            ?>

        </p>
        <a href="logout.php">Logout</a>
    </div>
</body>

</html>