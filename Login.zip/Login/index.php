<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register & Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- Notification Section -->
    <div id="notification" class="notification"></div>

    <div class="container" id="signup" style="display:none;">
        <h1 class="form-title">Register</h1>
        <form method="post" action="register.php" onsubmit="return validatePassword()">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="fName" id="fName" placeholder="First Name" required>
                <label for="fName">First Name</label>
            </div>
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="lName" id="lName" placeholder="Last Name" required>
                <label for="lName">Last Name</label>
            </div>
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="registerEmail" placeholder="Email" required>
                <label for="registerEmail">Email</label>
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="registerPassword" placeholder="Password" required>
                <label for="registerPassword">Password</label>
                <span id="passwordError" style="color:red; display:none;">Password must be at least 8 characters long,
                    include at least one uppercase letter, one lowercase letter, one number, and one special
                    character.</span>
            </div>
            <input type="submit" class="btn" value="Sign Up" name="signUp">
        </form>
        <!-- <p class="or">----------or--------</p>
      <div class="icons">
        <i class="fab fa-google"></i>
        <i class="fab fa-facebook"></i>
      </div> -->
        <div class="links">
            <p>Already Have Account?</p>
            <button id="signInButton">Sign In</button>
        </div>
    </div>

    <div class="container" id="signIn">
        <h1 class="form-title">Sign In</h1>
        <form method="post" action="register.php">
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="loginEmail" placeholder="Email" required>
                <label for="loginEmail">Email</label>
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="loginPassword" placeholder="Password" required>
                <label for="loginPassword">Password</label>
            </div>
            <!-- <p class="recover">
            <a href="#">Recover Password</a>
          </p> -->
            <input type="submit" class="btn" value="Sign In" name="signIn">
        </form>
        <!-- <p class="or">----------or--------</p>
        <div class="icons">
          <i class="fab fa-google"></i>
          <i class="fab fa-facebook"></i>
        </div> -->
        <div class="links">
            <p>Don't have an account yet?</p>
            <button id="signUpButton">Sign Up</button>
        </div>
    </div>

    <script src="script.js"></script>

    <?php
    session_start();
    // Check for registration success notification
    if (isset($_SESSION['registration_success'])) {
        echo "<script>document.getElementById('notification').innerText = '" . $_SESSION['registration_success'] . "';</script>";
        unset($_SESSION['registration_success']); // Clear the notification after displaying
    }

    // Check for password error notification
    if (isset($_SESSION['password_error'])) {
        echo "<script>document.getElementById('notification').innerText = '" . $_SESSION['password_error'] . "';</script>";
        unset($_SESSION['password_error']); // Clear the notification after displaying
    }

    // Check for email error notification
    if (isset($_SESSION['email_error'])) {
        echo "<script>document.getElementById('notification').innerText = '" . $_SESSION['email_error'] . "';</script>";
        unset($_SESSION['email_error']); // Clear the notification after displaying
    }
    ?>

    <script>
        function validatePassword() {
            const password = document.getElementById('registerPassword').value;
            const passwordError = document.getElementById('passwordError');
            const strongPasswordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

            if (!strongPasswordPattern.test(password)) {
                passwordError.style.display = 'block';
                return false; // Prevent form submission
            } else {
                passwordError.style.display = 'none';
                return true; // Allow form submission
            }
        }
    </script>
</body>

</html>